# -*- coding: utf-8 -*-
"""
Created on Sun Jan 24 14:21:35 2021

@author: Kamlesh
"""

import os,re
text_file = open("acronyms.txt", "r")
lines = text_file.readlines()
text_file.close()
acronyms=[n.encode("ascii",'ignore').decode("ascii",'ignore') for n in lines]
acronyms=[n.split(" - ")[1] for n in lines if len(n.split(" - "))==2]

acronymDict={}
acronymList=[n.split(" - ") for n in lines if len(n.split(" - "))==2]
for n in acronymList:
    if len(n[0])>2 and len(str(n[1]).strip())>0:
        acronymDict[n[0].upper()]=str(n[1]).replace("\n","").strip()
    else:
        pass


text_file = open("englishContractions.txt", "r")
lines = text_file.readlines()
text_file.close()
englishContractions=[n.split(" - ") for n in lines]
for n in englishContractions:
    acronymDict[n[0]]=str(n[1]).replace("\n","").strip()
    


pattern="|".join([w for w in list(acronymDict.keys())])
pattern=r""+pattern+""


def getExpansion(pat):
    expansion=acronymDict.get(pat.group(0)).lower()
    if expansion:
        return expansion
    else:
        return pat

def expandContractions(s):
    s=re.sub(pattern,getExpansion,s)
    return s